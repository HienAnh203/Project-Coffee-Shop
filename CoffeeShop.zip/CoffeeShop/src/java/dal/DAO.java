/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.util.ArrayList;
import java.util.List;

import java.sql.PreparedStatement;//chay lenh sql
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;
import model.Category;
import model.Product;


public class DAO extends DBContext{
    
    public List<Category> getAll(){
        List<Category> list=new ArrayList<>();
        String sql="select * from Category";
        try{
            PreparedStatement st=connection.prepareStatement(sql);
            ResultSet rs=st.executeQuery();
            while(rs.next()){
                Category c=new Category(rs.getInt("cid"), rs.getString("cname"));
                list.add(c);          
            }
        }catch(SQLException e){
            
        }
        return list;
    }
    
    public Category getCategoryById(int id){
        String sql="select * from Category where cid=?";
        try{
            PreparedStatement st=connection.prepareStatement(sql);
            st.setInt(1, id);
            ResultSet rs=st.executeQuery();
            if(rs.next()){
                Category c=new Category(rs.getInt("cid"), rs.getString("cname"));
                return c;
            }
        }catch(SQLException e){
            
        }
        return null;
    }
    
    public void updateC(Category c) {
        
        String sql = "update Category set cname=? where cid=?";
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            st.setString(1, c.getCname());
            st.setInt(2, c.getCid());

            st.executeUpdate();
        } catch (SQLException e) {

        }
    }
    
    public void insert(Category c){
        String sql="insert into Category(cid,cname) values(?,?)";
        try{
            PreparedStatement st=connection.prepareStatement(sql);
            st.setInt(1, c.getCid());
            st.setString(2, c.getCname());

            st.executeUpdate();
        }catch(SQLException e){
            
        }
    }
    
    
    
    
    
    public List<Product> getAllProducts() {
        List<Product> list = new ArrayList<>();
        String sql = "select * from product";
        try {
            
            PreparedStatement st = connection.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Product product = new Product();
                product.setId(rs.getInt(1));
                product.setName(rs.getString(2));
                product.setImage(rs.getString(3));
                product.setPrice(rs.getInt(4));
                product.setDescription(rs.getString(5));
                product.setCateID(rs.getInt(6));               
                list.add(product);
            }
        } catch (Exception ex) {
            //Logger.getLogger(CategoryDBContext.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
    
    public List<Product> getProductsByCategoryId(String cid) {
        List<Product> list = new ArrayList<>();
        String sql = "select * from Product where Product.cateID = ?";
        try {
            

            PreparedStatement st = connection.prepareStatement(sql);
            st.setString(1, cid);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Product product = new Product();
                product.setId(rs.getInt(1));
                product.setName(rs.getString(2));
                product.setImage(rs.getString(3));
                product.setPrice(rs.getInt(4));              
                product.setDescription(rs.getString(5));
                product.setCateID(rs.getInt(6));               
                list.add(product);
            }
        } catch (Exception ex) {
            
        }
        return list;
    }
    
    public List<Product> getProductsWithoutCate(String id) {
        List<Product> list = new ArrayList<>();
        String sql = "select p.id,p.name,p.image,p.price,p.description,c.cname AS category_name"
                +"FROM product p join category c on p.cateID = c.cid";
        try {

            PreparedStatement st = connection.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                
                Product p = new Product();               
                p.setId(rs.getInt("id"));
                p.setName(rs.getString("name"));
                p.setImage(rs.getString("image"));
                p.setPrice(rs.getInt("price"));
                p.setDescription(rs.getString("description"));
                p.setCateID(rs.getInt("cateID"));
                
                Category c = new Category(rs.getInt("cid"), rs.getString("cname"));
                list.add(p);
            }
        } catch (Exception ex) {

        }
        return list;
    }
    
    public int getTotalProducts() {
        String sql = "select count(id)  from Product ";
        try {
            

            PreparedStatement st = connection.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception ex) {
            //Logger.getLogger(CategoryDBContext.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }
    
    public List<Product> search(String keyword) {
        List<Product> list = new ArrayList<>();
        String sql = "select *  from Product where name like ?";
        try {
            

            PreparedStatement st = connection.prepareStatement(sql);
            st.setString(1, "%" + keyword + "%");
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Product product = new Product();
                product.setId(rs.getInt(1));
                product.setName(rs.getString(2));
                product.setImage(rs.getString(3));
                product.setPrice(rs.getInt(4));
                product.setDescription(rs.getString(5));
                product.setCateID(rs.getInt(6)); 
                list.add(product);

            }
        } catch (Exception ex) {
            
        }
        return list;
    }
    
    public Product getProductById(String id) {
        String sql = "select *  from Product where id = ?";
        try {
            
            PreparedStatement st = connection.prepareStatement(sql);
            st.setString(1, id);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Product product = new Product();
                product.setId(rs.getInt(1));
                product.setName(rs.getString(2));
                product.setImage(rs.getString(3));
                product.setPrice(rs.getInt(4));
                product.setDescription(rs.getString(5));
                product.setCateID(rs.getInt(6));
                return product;
            }
        } catch (Exception ex) {
            
        }
        return null;
    }
    
    public void insertProduct(Product product) {
        String sql="insert into product(id,name,image,price,description,cateID) values (?,?,?,?,?,?)";
        try {        

            PreparedStatement rs = connection.prepareStatement(sql);
            rs.setString(1, product.getName());
            rs.setString(2, product.getImage());
            rs.setDouble(3, product.getPrice());
            rs.setString(4, product.getDescription());
            rs.setInt(6, product.getCateID());
            rs.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    public void deleteProduct(int id) {
        try {
            String sql = "delete from product where id=?";
            PreparedStatement stm = connection.prepareStatement(sql);
            stm.setInt(1, id);
            stm.executeUpdate();
        } catch (SQLException ex) {
            
        }
    }
    

    public void updateProduct(Product p) {
        String sql = "update product set name=?,image=? ,price=?, description=? ,cateID=? where id=?";
        try {
            
            PreparedStatement st=connection.prepareStatement(sql);
            st.setString(1, p.getName());
            st.setString(2, p.getImage());
            st.setDouble(3, p.getPrice());
            st.setString(4, p.getDescription());
            st.setInt(5, p.getCateID());
            st.setInt(6, p.getId());
            st.executeUpdate();

        } catch (SQLException ex) {
            
        }
    }
    
    public List<Product> getAllProductsLast() {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT TOP 3 * FROM product ORDER BY ID DESC";
        try {
            
            PreparedStatement st = connection.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Product product = new Product();
                product.setId(rs.getInt(1));
                product.setName(rs.getString(2));
                product.setImage(rs.getString(3));
                product.setPrice(rs.getInt(4));
                product.setDescription(rs.getString(5));
                product.setCateID(rs.getInt(6));
                list.add(product);
            }
        } catch (Exception ex) {
           
        }
        return list;
    }
    
    public static void main(String[] args) {
        DAO d = new DAO();
        String id="37";
        List<Product> list = d.getProductsWithoutCate(id);
        for (Product product : list) {
            System.out.println(product.getName());
        }
    }
    
    


    
    
    
    
    
}