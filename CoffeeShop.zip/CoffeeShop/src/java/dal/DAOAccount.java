/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Account;

/**
 *
 * @author msi
 */
public class DAOAccount extends DBContext{
    public List<Account> getAllAccount() {
        List<Account> list = new ArrayList<>();
        String sql = "select * from Account where role !=1";
        try {
            
            PreparedStatement st = connection.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Account account = new Account();
                account.setuID(rs.getInt(1));
                account.setUsername(rs.getString(2));
                account.setPass(rs.getString(3));
                account.setRole(rs.getInt(4));
                

                list.add(account);
            }
        } catch (SQLException e) {
            
        }
        return list;
    }
    
    public Account login(String user, String pass) {
        String sql = "SELECT * FROM Account where username = ? and pass = ?";
        try {
            
            PreparedStatement st = connection.prepareStatement(sql);
            st.setString(1, user);
            st.setString(2, pass);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Account a = new Account();
                a.setuID(rs.getInt(1));
                a.setUsername(rs.getString(2));
                a.setPass(rs.getString(3));
                a.setRole(rs.getInt(4));

                return a;
            }
        } catch (SQLException e) {
           
        }
        return null;
    }

    public Account checkAccountExist(String user) {
        try {
            String sql = "SELECT * FROM Account where username = ?";
            PreparedStatement stm = connection.prepareStatement(sql);
            stm.setString(1, user);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Account a = new Account();
                a.setuID(rs.getInt(1));
                a.setUsername(rs.getString(2));
                a.setPass(rs.getString(3));
                a.setRole(rs.getInt(4));

                return a;
            }
        } catch (SQLException ex) {
            
        }
        return null;
    }
    public Account checkAuthen(String username,String password){
        String sql="select * from Account where username=? and pass=?";
        try{
            PreparedStatement st=connection.prepareStatement(sql);
            st.setString(1, username);
            st.setString(2, password);
            ResultSet rs=st.executeQuery();
            if(rs.next()){
                return new Account(rs.getInt("uID"),username, password, rs.getInt("role"));
            }
        }catch(SQLException e){
            System.out.println(e);
        }
        return null;
    }

    public void insertAccount(String user, String pass) {
    String sql = "INSERT INTO Account (username, pass, role) VALUES (?, ?, 0)";
    try {
        PreparedStatement st = connection.prepareStatement(sql);
        st.setString(1, user);
        st.setString(2, pass);
        st.executeUpdate();
    } catch (SQLException ex) {
        
    }
}


    public Account getAccountById(int uID) {
        String sql = "select *  from Account where uID =?";
        try {
            
            PreparedStatement st = connection.prepareStatement(sql);
            st.setInt(1, uID);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Account account = new Account();
                account.setuID(rs.getInt(1));
                account.setUsername(rs.getString(2));
                account.setPass(rs.getString(3));
                account.setRole(rs.getInt(4));


                return account;
            }
        } catch (Exception ex) {

        }
        return null;
    }
    
    public boolean checkUser(String username){
        String sql="select * from admin where username=?";
        try{
            PreparedStatement st=connection.prepareStatement(sql);
            st.setString(1, username);
            ResultSet rs=st.executeQuery();
            if(rs.next()){
                return true;
            }
        }catch(SQLException e){
            System.out.println(e);
        }
        return false;
    }
    
    public void UpDatePassWord(String pass, String user) {
        try {
            String sql = "UPDATE Account SET pass =?   WHERE user = ?";
            PreparedStatement st = connection.prepareStatement(sql);
            st.setString(1, pass);
            st.setString(2, user);
            st.executeUpdate();
        } catch (SQLException ex) {
           
        }
    }
    
    
    
    
}
