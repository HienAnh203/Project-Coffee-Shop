/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Category;

/**
 *
 * @author msi
 */
public class DAOCategory extends DBContext{
    public List<Category> getAll(){
        List<Category> list=new ArrayList<>();
        String sql="select * from Category";
        try{
            PreparedStatement st=connection.prepareStatement(sql);
            ResultSet rs=st.executeQuery();
            while(rs.next()){
                Category c=new Category(rs.getInt("cid"), rs.getString("cname"));
                list.add(c);          
            }
        }catch(SQLException e){
            
        }
        return list;
    }
    
    public Category getCategoryById(int id){
        String sql="select * from Category where cid=?";
        try{
            PreparedStatement st=connection.prepareStatement(sql);
            st.setInt(1, id);
            ResultSet rs=st.executeQuery();
            if(rs.next()){
                Category c=new Category(rs.getInt("cid"), rs.getString("cname"));
                return c;
            }
        }catch(SQLException e){
            
        }
        return null;
    }
    
    public void insert(Category c){
        String sql="insert into Category (cid,cname) values(?,?)";
        try{
            PreparedStatement st=connection.prepareStatement(sql);
            st.setInt(1, c.getCid());
            st.setString(2, c.getCname());

            st.executeUpdate();
        }catch(SQLException e){
            
        }
    }
    
    public void deleteCategory(int id) {
        try {
            String sql = "delete  from Category where cid=?";
            PreparedStatement st = connection.prepareStatement(sql);
            st.setInt(1, id);
            st.executeUpdate();
        } catch (SQLException ex) {
            
        }
    }
}
